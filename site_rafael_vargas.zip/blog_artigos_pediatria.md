# Artigos do Blog — pilar Ortopedia Pediátrica (Dr. Rafael Vargas)
> Publicados na Livance em 21/06/2026 (ids 43814, 43815). CFM-safe: educativo, sem promessa de resultado, paciente não identificável, assinatura nome+CRM+RQE + disclaimer. Complementa `blog_artigos.md` (pilar reconstrução).

---

## Artigo 4 — Quando levar a criança ao ortopedista: sinais que merecem avaliação

Muitas alterações ortopédicas na infância fazem parte do desenvolvimento normal e se resolvem sozinhas com o crescimento. Outras, porém, merecem avaliação. Saber diferenciar ajuda a procurar ajuda na hora certa — nem cedo demais a ponto de gerar ansiedade, nem tarde a ponto de perder a melhor janela de tratamento.

Sinais que merecem atenção. Vale uma avaliação quando os pais ou o pediatra observam: assimetria entre os lados (uma perna ou um braço diferente do outro); desvios de eixo acentuados ou que pioram (pernas muito arqueadas ou em xis além do esperado para a idade); claudicação (mancar) sem causa clara; diferença aparente no comprimento das pernas; ou deformidades associadas a uma doença de base já conhecida.

Por que a idade importa. A criança está em crescimento, e o osso responde a esse processo. Existe uma janela em que certas correções são mais favoráveis — por isso o acompanhamento ao longo do tempo, e não apenas uma avaliação isolada, é tão importante. Avaliar cedo não significa, necessariamente, tratar cedo: muitas vezes significa observar com método e agir no momento adequado.

Como é a avaliação. Combina conversa com a família, exame físico e, quando indicado, exames de imagem e medidas. O objetivo é entender se aquilo faz parte do desenvolvimento normal ou se há algo que se beneficia de acompanhamento ou tratamento — sempre explicando aos pais o que esperar de cada etapa.

A mensagem para os pais. Na dúvida, vale conversar. Uma avaliação tranquiliza quando está tudo dentro do esperado e permite planejar com calma quando há algo a acompanhar.

*Este conteúdo é informativo e educativo, não substitui a consulta médica presencial nem estabelece relação médico-paciente. Cada caso exige avaliação individual; não há garantia de resultado.*

**Dr. Rafael Vargas — Médico · CRM-SP 226103 · RQE 137901**
Ortopedia Pediátrica · Reconstrução e Alongamento Ósseo — São Paulo

---

## Artigo 5 — Deformidades dos membros na infância: por que acompanhar ao longo do crescimento

Quando uma criança apresenta uma deformidade nos membros, uma dúvida comum dos pais é: "precisa operar agora?". Na ortopedia pediátrica, a resposta quase nunca é imediata — e isso costuma ser uma boa notícia. Muitas condições se beneficiam de acompanhamento ao longo do crescimento, com decisões tomadas no momento mais favorável.

O crescimento como aliado (e como desafio). O osso da criança cresce, e esse crescimento pode tanto corrigir espontaneamente certas alterações quanto acentuar outras. Entender para que lado a deformidade tende a evoluir é parte central da avaliação — e isso fica mais claro com acompanhamento ao longo do tempo, não com uma avaliação isolada.

Deformidades associadas a doenças de base. Algumas deformidades aparecem no contexto de condições como displasias, raquitismo ou outras doenças que afetam o osso. Nesses casos, o acompanhamento é ainda mais importante, porque a deformidade pode retornar ou progredir, exigindo um plano de longo prazo, em etapas.

Nem cedo demais, nem tarde demais. Intervir antes da hora pode ser desnecessário; adiar demais pode significar perder a janela em que a correção é mais favorável. O equilíbrio vem do acompanhamento individualizado, em que cada etapa é discutida com a família.

A mensagem principal. Deformidade na infância raramente é uma decisão de "agora ou nunca". É, na maioria das vezes, um acompanhamento — planejado com cuidado, explicado com clareza e ajustado conforme a criança cresce.

*Este conteúdo é informativo e educativo, não substitui a consulta médica presencial nem estabelece relação médico-paciente. Cada caso exige avaliação individual; não há garantia de resultado.*

**Dr. Rafael Vargas — Médico · CRM-SP 226103 · RQE 137901**
Ortopedia Pediátrica · Reconstrução e Alongamento Ósseo — São Paulo
