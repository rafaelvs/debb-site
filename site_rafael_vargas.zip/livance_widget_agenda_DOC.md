# Documentação — Widget de Agenda Livance (para embutir no site custom)
> Fonte: https://storage.googleapis.com/livance-static/docs/index.html (enviada pela Raissa/Livance, Ticket #322042, em 23/06/2026). Salvo em 23/06/2026.

## O que é
O **widget da Livance** permite integrar a seção de **agendamentos** em qualquer site HTML. Basta adicionar o código abaixo à página; o carregamento é automático (a altura do iframe se ajusta sozinha via iframe-resizer).

- **Só funciona em HTTPS** (restrição de segurança).
- O widget é um `<iframe>` que aponta para `https://[subdomínio].healthoffices.com.br/Widget`.
- Formato do subdomínio: `[nomedoprofissional].healthoffices.com.br`.

## Subdomínio do Dr. Rafael
A Raissa informou no e-mail: **`rafaelvargas-pvd`**.
→ Portanto a URL do widget deve ser: **`https://rafaelvargas-pvd.healthoffices.com.br/Widget`**
(⚠️ confirmar com a Livance se o host completo é exatamente `rafaelvargas-pvd.healthoffices.com.br` — a doc usa o formato `.healthoffices.com.br`, mas ela passou só o rótulo `rafaelvargas-pvd`.)

## Código de embed (genérico, da doc)
```html
<style>iframe{width: 1px;min-width: 100%;}</style>

<iframe id="iframe-livance" src="https://[nomedoprofissional].healthoffices.com.br/Widget" frameborder="0" scrolling="no" style="overflow: hidden;"></iframe>

<script type="text/javascript">
if("undefined"==typeof jQuery){var a=document.createElement("script");a.type="text/javascript";a.src="https://code.jquery.com/jquery-3.2.1.slim.min.js";document.head.insertBefore(a,document.head.getElementsByTagName("script")[0])};
</script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/iframe-resizer/3.6.0/iframeResizer.min.js"></script>
<script>iFrameResize({log:false}, '#iframe-livance')</script>
```

## Código já pronto para o Dr. Rafael (subdomínio preenchido)
```html
<style>iframe{width: 1px;min-width: 100%;}</style>

<iframe id="iframe-livance" src="https://rafaelvargas-pvd.healthoffices.com.br/Widget" frameborder="0" scrolling="no" style="overflow: hidden;"></iframe>

<script type="text/javascript">
if("undefined"==typeof jQuery){var a=document.createElement("script");a.type="text/javascript";a.src="https://code.jquery.com/jquery-3.2.1.slim.min.js";document.head.insertBefore(a,document.head.getElementsByTagName("script")[0])};
</script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/iframe-resizer/3.6.0/iframeResizer.min.js"></script>
<script>iFrameResize({log:false}, '#iframe-livance')</script>
```

## Como usar no plano de migração
Quando o site custom (`index.html`) estiver hospedado e o domínio apontar para ele, colar esse bloco na seção de agendamento substitui/complementa os botões atuais (Doctoralia/WhatsApp) com a **agenda nativa da Livance** embutida — mantendo o fluxo de marcação dentro do próprio site.
