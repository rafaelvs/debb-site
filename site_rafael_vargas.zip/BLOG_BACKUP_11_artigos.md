# BACKUP — Blog completo do Dr. Rafael Vargas (11 artigos)
> Backup consolidado em 23/06/2026, antes da eventual migração do domínio (site Livance → site custom). Todos publicados no blog da Livance (ids 43814/43815 e seguintes até 43837). CFM-safe (Res. CFM 2.336/2023): educativo, sem promessa de resultado, paciente não identificável, assinatura nome+CRM+RQE + disclaimer. Guardrail: alongamento ósseo só em contexto funcional, nunca estético/altura.
>
> Fontes originais (mantidas): blog_artigos.md (1-3), blog_artigos_pediatria.md (4-5), blog_artigos_extra.md (6-8), blog_artigos_pediatria2.md (9-11).
> Assinatura padrão de todos: **Dr. Rafael Vargas — Médico · CRM-SP 226103 · RQE 137901** — Ortopedia Pediátrica · Reconstrução e Alongamento Ósseo — São Paulo
> Disclaimer padrão: *Este conteúdo é informativo e educativo, não substitui a consulta médica presencial nem estabelece relação médico-paciente. Cada caso exige avaliação individual; não há garantia de resultado.*

---

## 1 — Discrepância de comprimento dos membros ("perna mais curta"): o que é e quando avaliar

Você já reparou que uma perna parece mais curta que a outra, que há uma claudicação ao andar ou que um dos sapatos desgasta diferente? A diferença de comprimento entre os membros — chamada de discrepância de comprimento dos membros — é uma condição relativamente comum, que pode surgir no nascimento ou ao longo da vida.

Por que acontece? As causas são variadas: diferenças congênitas, sequelas de fraturas que consolidaram em posição inadequada, infecções ósseas, alterações do crescimento na infância ou doenças de base que afetam o desenvolvimento do osso. Em crianças, a diferença pode aumentar à medida que crescem, por isso o acompanhamento ao longo do crescimento é importante.

Por que avaliar? Diferenças pequenas muitas vezes não causam sintomas. Já diferenças maiores podem se associar a claudicação, sobrecarga da coluna e das articulações e desconforto ao caminhar. A avaliação busca entender a magnitude da diferença, sua causa e como ela tende a evoluir — especialmente na criança em crescimento, em que existe uma "janela" de tratamento que muda conforme a idade.

Como é a avaliação? Combina exame clínico, medidas e exames de imagem para medir a diferença com precisão e investigar a origem. A partir desse entendimento, discute-se, de forma individualizada, o que faz sentido para cada caso — desde acompanhamento até abordagens de correção, sempre explicando as alternativas e o que esperar de cada etapa.

Quando procurar um especialista? Vale uma avaliação quando há diferença perceptível no comprimento das pernas, claudicação, ou quando uma criança apresenta assimetria que parece aumentar com o tempo. O encaminhamento precoce ajuda a planejar com calma, no momento mais adequado.

---

## 2 — Pseudartrose: quando a fratura não consolida

A maioria das fraturas consolida (cola) dentro de um período esperado. Quando esse processo não acontece e o osso permanece sem unir além do tempo previsto, falamos em pseudartrose — literalmente, uma "falsa articulação", em que persiste mobilidade no ponto que deveria estar consolidado.

Por que algumas fraturas não consolidam? A consolidação depende de fatores como estabilidade no foco da fratura, vascularização (irrigação sanguínea) e ausência de infecção. Fraturas expostas, perdas ósseas, infecções, certas localizações e fatores individuais podem dificultar a união. Identificar por que aquela fratura não consolidou é parte central da avaliação, porque orienta a conduta.

Quais sinais chamam atenção? Dor persistente no local, sensação de instabilidade ou movimento anormal, e dificuldade de uso do membro tempos depois de uma fratura que "deveria" ter colado. O diagnóstico é confirmado com exame clínico e de imagem.

Como se avalia o tratamento? O planejamento é individualizado e costuma considerar a estabilidade do foco, a qualidade do osso e dos tecidos ao redor, e a presença ou não de infecção. Técnicas de reconstrução óssea — incluindo, em casos selecionados, o uso de fixadores e a correção gradual — fazem parte do arsenal da ortopedia reconstrutiva para esse tipo de problema. Cada alternativa, com seus riscos e suas etapas, é discutida com o paciente.

Por que procurar avaliação especializada? A pseudartrose costuma ser um problema de difícil solução, que se beneficia de planejamento minucioso e visão de longo prazo. Se você convive com dor e instabilidade muito tempo após uma fratura, vale uma avaliação para entender a causa e os caminhos possíveis.

---

## 3 — Fixador externo e correção gradual: entendendo o tratamento das deformidades

Quando se fala em fixador externo, é comum surgir certo receio — em parte por desconhecimento de como o tratamento funciona no dia a dia. Este texto busca explicar, de forma educativa, o papel dessa ferramenta na correção de deformidades e na reconstrução óssea.

O que é? O fixador externo é um dispositivo que estabiliza o osso a partir de fora do corpo, por meio de pinos ou fios. Ele permite, em situações selecionadas, fazer correções de forma gradual — ajustando alinhamento e comprimento ao longo do tempo, respeitando a biologia do osso e dos tecidos.

Em que situações pode ser indicado? Correção de deformidades dos membros (desvios de eixo), tratamento de discrepância de comprimento, reconstrução em casos de perda óssea, sequelas de fraturas e de infecções, e algumas pseudartroses. A indicação é sempre individualizada: nem todo caso precisa de fixador, e a decisão considera o objetivo funcional de cada pessoa.

Como é conviver com o fixador? O tratamento é conduzido em etapas, com acompanhamento ao longo do período. Os cuidados com os pinos, a rotina e o tempo de uso são explicados com clareza desde o início, para que o paciente e a família saibam o que esperar de cada fase. A correção gradual exige paciência, e o acompanhamento próximo faz parte do processo.

A mensagem principal: o fixador é um meio para um fim — restaurar função, alinhamento e qualidade de vida em quadros complexos. Mais importante que a ferramenta é o planejamento por trás dela: entender a causa da deformidade e construir, junto com o paciente, um plano realista e individualizado.

---

## 4 — Quando levar a criança ao ortopedista: sinais que merecem avaliação

Muitas alterações ortopédicas na infância fazem parte do desenvolvimento normal e se resolvem sozinhas com o crescimento. Outras, porém, merecem avaliação. Saber diferenciar ajuda a procurar ajuda na hora certa — nem cedo demais a ponto de gerar ansiedade, nem tarde a ponto de perder a melhor janela de tratamento.

Sinais que merecem atenção. Vale uma avaliação quando os pais ou o pediatra observam: assimetria entre os lados (uma perna ou um braço diferente do outro); desvios de eixo acentuados ou que pioram (pernas muito arqueadas ou em xis além do esperado para a idade); claudicação (mancar) sem causa clara; diferença aparente no comprimento das pernas; ou deformidades associadas a uma doença de base já conhecida.

Por que a idade importa. A criança está em crescimento, e o osso responde a esse processo. Existe uma janela em que certas correções são mais favoráveis — por isso o acompanhamento ao longo do tempo, e não apenas uma avaliação isolada, é tão importante. Avaliar cedo não significa, necessariamente, tratar cedo: muitas vezes significa observar com método e agir no momento adequado.

Como é a avaliação. Combina conversa com a família, exame físico e, quando indicado, exames de imagem e medidas. O objetivo é entender se aquilo faz parte do desenvolvimento normal ou se há algo que se beneficia de acompanhamento ou tratamento — sempre explicando aos pais o que esperar de cada etapa.

A mensagem para os pais. Na dúvida, vale conversar. Uma avaliação tranquiliza quando está tudo dentro do esperado e permite planejar com calma quando há algo a acompanhar.

---

## 5 — Deformidades dos membros na infância: por que acompanhar ao longo do crescimento

Quando uma criança apresenta uma deformidade nos membros, uma dúvida comum dos pais é: "precisa operar agora?". Na ortopedia pediátrica, a resposta quase nunca é imediata — e isso costuma ser uma boa notícia. Muitas condições se beneficiam de acompanhamento ao longo do crescimento, com decisões tomadas no momento mais favorável.

O crescimento como aliado (e como desafio). O osso da criança cresce, e esse crescimento pode tanto corrigir espontaneamente certas alterações quanto acentuar outras. Entender para que lado a deformidade tende a evoluir é parte central da avaliação — e isso fica mais claro com acompanhamento ao longo do tempo, não com uma avaliação isolada.

Deformidades associadas a doenças de base. Algumas deformidades aparecem no contexto de condições como displasias, raquitismo ou outras doenças que afetam o osso. Nesses casos, o acompanhamento é ainda mais importante, porque a deformidade pode retornar ou progredir, exigindo um plano de longo prazo, em etapas.

Nem cedo demais, nem tarde demais. Intervir antes da hora pode ser desnecessário; adiar demais pode significar perder a janela em que a correção é mais favorável. O equilíbrio vem do acompanhamento individualizado, em que cada etapa é discutida com a família.

A mensagem principal. Deformidade na infância raramente é uma decisão de "agora ou nunca". É, na maioria das vezes, um acompanhamento — planejado com cuidado, explicado com clareza e ajustado conforme a criança cresce.

---

## 6 — Joelho varo e valgo na criança (pernas arqueadas ou em "xis"): quando avaliar

É comum os pais notarem que a criança tem as pernas "arqueadas" (joelho varo) ou em formato de "xis" (joelho valgo) e ficarem na dúvida se é normal. Na maioria das vezes, faz parte do desenvolvimento — mas alguns casos merecem avaliação.

O que é normal no desenvolvimento. O alinhamento das pernas muda com a idade: bebês costumam ter as pernas mais arqueadas (varo), que tendem a se corrigir nos primeiros anos; mais tarde, por volta dos 3 a 4 anos, é comum um período de joelho valgo ("xis"), que também costuma se ajustar com o crescimento. Ou seja, ver uma curvatura em certa idade nem sempre é problema.

Quando merece avaliação. Vale procurar um especialista quando a curvatura é acentuada ou aparece só de um lado (assimétrica); quando piora em vez de melhorar com a idade; quando vem acompanhada de baixa estatura desproporcional, dor ou claudicação; ou quando há uma doença de base conhecida (como raquitismo ou displasias). Esses sinais ajudam a diferenciar o que é desenvolvimento do que precisa de acompanhamento.

Como é a avaliação. Inclui exame clínico, observação da marcha, medidas do alinhamento e, quando indicado, exames de imagem. O objetivo é entender se a curvatura tende a se corrigir sozinha ou se há algo que se beneficia de acompanhamento ou tratamento — sempre explicando aos pais o que esperar.

A mensagem para os pais. Curvatura nas pernas da criança costuma ser parte do crescimento. Mas assimetria, piora ou dor merecem uma avaliação, que tranquiliza quando está tudo certo e permite agir na hora certa quando é necessário.

---

## 7 — Consolidação viciosa: quando a fratura cola fora do lugar

Nem toda fratura que "cola" consolida na posição ideal. Quando o osso une, mas com desvio de alinhamento, rotação ou encurtamento, chamamos de consolidação viciosa. Diferente da pseudartrose (em que o osso não chega a unir), aqui o osso consolidou — só que fora da posição correta.

Por que acontece. Pode resultar de uma fratura que consolidou sem alinhamento adequado, de desvios que surgem durante a consolidação, ou de fraturas complexas em que manter a posição é difícil. Em crianças, o crescimento às vezes corrige parte do desvio — em outras, pode acentuá-lo, por isso o acompanhamento importa.

Quais as consequências. Dependendo do grau e da localização, a consolidação viciosa pode causar desalinhamento visível do membro, diferença de comprimento, alteração da marcha, sobrecarga das articulações vizinhas e desconforto. Casos leves podem não dar sintomas; outros se beneficiam de correção.

Como se avalia o tratamento. A avaliação mede o desvio (angular, rotacional e de comprimento) com exame clínico e de imagem, e considera o impacto funcional. Quando indicada, a correção pode envolver técnicas de reconstrução — incluindo osteotomias (cortes ósseos planejados) e, em casos selecionados, correção gradual com fixadores. Cada caso é individualizado e discutido com o paciente.

Quando procurar avaliação. Se você percebe um membro "torto" depois de uma fratura, diferença de comprimento ou dificuldade para usá-lo, vale uma avaliação para entender o desvio e os caminhos possíveis.

---

## 8 — Sequelas de fraturas e de infecções ósseas: quando a reconstrução entra

Algumas fraturas e infecções ósseas deixam sequelas que vão além do episódio inicial: perda de osso, desalinhamento, encurtamento, rigidez ou áreas que não cicatrizam bem. Esses quadros — muitas vezes de difícil solução — são parte central da ortopedia reconstrutiva.

Que tipo de sequela. Entre as mais comuns estão: pseudartrose (fratura que não consolida), consolidação viciosa (osso unido fora de posição), discrepância de comprimento, perda óssea segmentar (falta de um trecho do osso) e sequelas de osteomielite (infecção do osso). Com frequência, mais de um desses problemas coexistem.

Por que exigem planejamento. Tratar uma sequela não é repetir a cirurgia inicial — é entender o que ficou para trás (osso, partes moles, presença ou não de infecção) e construir um plano em etapas. O controle de uma eventual infecção costuma ser pré-requisito antes de reconstruir.

Como a reconstrução ajuda. O arsenal inclui técnicas de reconstrução e alongamento ósseo, transporte ósseo para preencher perdas, correção de eixo e de comprimento, e o uso de fixadores com correção gradual quando indicado — sempre individualizado, priorizando função, alinhamento e qualidade de vida.

Quando procurar avaliação. Se você convive com as consequências de uma fratura ou infecção óssea antiga — dor, desalinhamento, encurtamento ou feridas que não fecham — vale uma avaliação especializada para entender a causa e os caminhos possíveis.

---

## 9 — Displasia do desenvolvimento do quadril (DDQ): por que avaliar cedo faz diferença

A displasia do desenvolvimento do quadril (DDQ) é uma condição em que a articulação do quadril não se forma ou não se mantém na posição adequada. Ela vai desde um quadril mais "frouxo" até situações em que a cabeça do fêmur fica fora do lugar (luxação). Quanto mais cedo é identificada, mais simples costuma ser o acompanhamento.

Por que acontece e quem tem mais risco. A DDQ tem relação com fatores como histórico familiar, posição pélvica na gestação (bebê sentado, "de nádegas"), ser o primeiro filho e o sexo feminino. Nem toda criança com fator de risco terá o problema — mas esses dados ajudam a decidir quem merece uma avaliação mais atenta.

Como é identificada. Nos primeiros meses, o exame clínico (manobras específicas no quadril do bebê) e, quando indicado, a ultrassonografia ajudam no diagnóstico; em crianças maiores, a radiografia passa a ser útil. Sinais como assimetria das pregas da coxa, diferença na abertura das pernas ou, mais tarde, um jeito diferente de andar podem chamar atenção.

Por que o tempo importa. Quando identificada cedo, a DDQ costuma ser conduzida com medidas mais simples e conservadoras. Diagnósticos mais tardios podem exigir condutas mais complexas. Por isso o acompanhamento nos primeiros meses e a triagem nas consultas de rotina são tão valorizados.

Quando procurar avaliação. Se há fatores de risco, assimetria nas pernas do bebê, dificuldade para abrir o quadril ou alteração na marcha quando a criança começa a andar, vale uma avaliação especializada — que tranquiliza quando está tudo bem e permite agir na hora certa quando necessário.

---

## 10 — Pé torto congênito: o que é e como é o acompanhamento

O pé torto congênito (pé equinovaro) é uma deformidade presente desde o nascimento em que o pé aparece virado para baixo e para dentro. É relativamente comum e, com acompanhamento adequado iniciado cedo, costuma ter boa evolução funcional.

O que se sabe sobre a causa. Na maioria dos casos é idiopático (sem uma causa única identificável), podendo haver componente genético; em parte dos casos está associado a outras condições. O importante para a família é entender que não se trata de "algo que os pais fizeram" — e que existe um caminho de tratamento bem estabelecido.

Como costuma ser conduzido. O acompanhamento moderno geralmente começa nas primeiras semanas de vida, com correção gradual por trocas de gesso (método de Ponseti) e, frequentemente, um procedimento simples no tendão de Aquiles, seguido do uso de órteses por um período para evitar recidiva. Cada caso é individualizado.

Por que a adesão importa. Boa parte do bom resultado depende de iniciar cedo e seguir todas as etapas, especialmente o uso das órteses na fase de manutenção. Interrupções aumentam a chance de o pé "voltar" para a posição antiga, o que pode demandar novas correções.

Quando procurar avaliação. Se o bebê nasceu com um ou ambos os pés virados, ou se há dúvida sobre o formato e a posição do pé, vale procurar avaliação especializada o quanto antes — o início precoce costuma simplificar todo o percurso.

---

## 11 — Como é a primeira consulta com o ortopedista: o que levar e o que esperar

A primeira consulta é o ponto de partida para entender o seu caso (ou o do seu filho) e construir um plano. Saber o que esperar ajuda a aproveitar melhor esse tempo.

O que levar. Vale reunir os exames de imagem já realizados (radiografias, tomografias, ressonâncias) — de preferência as imagens, não só os laudos —, relatórios de cirurgias ou tratamentos anteriores, a lista de medicamentos em uso e um breve histórico do problema (quando começou, como evoluiu, o que já foi tentado). No caso de crianças, informações sobre a gestação, o parto e o desenvolvimento podem ser úteis.

Como costuma ser. A consulta inclui conversa sobre a queixa e o histórico, exame físico (avaliação do alinhamento, da marcha e da mobilidade) e revisão dos exames trazidos. A partir disso, discutimos as hipóteses diagnósticas, a necessidade ou não de exames complementares e os caminhos possíveis — sempre explicando o porquê de cada conduta.

Sobre expectativas. Nem todo caso se resolve em uma única consulta: muitos quadros complexos exigem investigação por etapas e planejamento. O objetivo do primeiro encontro é entender o problema com clareza e alinhar os próximos passos, não necessariamente decidir tudo de imediato.

Perguntas são bem-vindas. Anote suas dúvidas antes da consulta — sobre diagnóstico, alternativas, riscos e tempo de recuperação. Uma boa decisão é aquela construída em conjunto, com informação clara.
