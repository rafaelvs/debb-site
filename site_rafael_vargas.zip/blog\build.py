# -*- coding: utf-8 -*-
"""
Gerador do blog do site custom do Dr. Rafael Vargas.
Fonte única de conteúdo: ../BLOG_BACKUP_11_artigos.md
Gera: blog/<slug>.html (11 artigos), blog/index.html (índice), blog/blog.css,
      e _home_blog_section.html (trecho p/ colar na home).
Rodar:  python build.py   (dentro da pasta blog/)
"""
import os, re, html

HERE = os.path.dirname(os.path.abspath(__file__))
SRC  = os.path.join(HERE, "..", "BLOG_BACKUP_11_artigos.md")
SITE = "https://www.rafaelvargasmd.com.br"

SIG = "Dr. Rafael Vargas — Médico · CRM-SP 226103 · RQE 137901 — Ortopedia Pediátrica · Reconstrução e Alongamento Ósseo — São Paulo"
DISC = ("Este conteúdo é informativo e educativo, não substitui a consulta médica presencial "
        "nem estabelece relação médico-paciente. Cada caso exige avaliação individual; não há garantia de resultado.")

# id -> (slug, meta description, date_iso, date_label)
META = {
 1:("discrepancia-de-comprimento-dos-membros",
    "Diferença de comprimento entre as pernas (perna mais curta): causas, quando avaliar e como é o tratamento. Dr. Rafael Vargas, ortopedista em São Paulo.",
    "2026-06-21","21 de junho de 2026"),
 2:("pseudartrose",
    "Pseudartrose é a fratura que não consolida. Por que acontece, sinais de alerta e os caminhos da reconstrução óssea. Dr. Rafael Vargas — São Paulo.",
    "2026-06-21","21 de junho de 2026"),
 3:("fixador-externo-e-correcao-gradual",
    "Fixador externo e correção gradual: o que é, quando é indicado e como é conviver com o tratamento de deformidades e reconstrução óssea. Dr. Rafael Vargas.",
    "2026-06-21","21 de junho de 2026"),
 4:("quando-levar-a-crianca-ao-ortopedista",
    "Sinais ortopédicos na infância que merecem avaliação: assimetria, claudicação, deformidades. Quando levar a criança ao ortopedista. Dr. Rafael Vargas, SP.",
    "2026-06-21","21 de junho de 2026"),
 5:("deformidades-dos-membros-na-infancia",
    "Deformidades dos membros na infância: por que muitas vezes o melhor é acompanhar ao longo do crescimento. Ortopedia pediátrica, Dr. Rafael Vargas — SP.",
    "2026-06-21","21 de junho de 2026"),
 6:("joelho-varo-e-valgo-na-crianca",
    "Pernas arqueadas (varo) ou em 'xis' (valgo) na criança: o que é normal e quando avaliar. Ortopedia pediátrica, Dr. Rafael Vargas — São Paulo.",
    "2026-06-22","22 de junho de 2026"),
 7:("consolidacao-viciosa",
    "Consolidação viciosa: quando a fratura cola fora do lugar. Consequências e opções de correção. Reconstrução óssea com Dr. Rafael Vargas, São Paulo.",
    "2026-06-22","22 de junho de 2026"),
 8:("sequelas-de-fraturas-e-infeccoes-osseas",
    "Sequelas de fraturas e infecções ósseas: perda óssea, desalinhamento, encurtamento. Quando a reconstrução entra. Dr. Rafael Vargas, ortopedista em SP.",
    "2026-06-22","22 de junho de 2026"),
 9:("displasia-do-desenvolvimento-do-quadril-ddq",
    "Displasia do desenvolvimento do quadril (DDQ): fatores de risco, como é identificada e por que avaliar cedo faz diferença. Ortopedia pediátrica, SP.",
    "2026-06-23","23 de junho de 2026"),
 10:("pe-torto-congenito",
    "Pé torto congênito (equinovaro): o que é, causas e como é o acompanhamento (método de Ponseti). Ortopedia pediátrica, Dr. Rafael Vargas — São Paulo.",
    "2026-06-23","23 de junho de 2026"),
 11:("primeira-consulta-com-o-ortopedista",
    "Primeira consulta com o ortopedista: o que levar (exames, histórico) e o que esperar. Orientações do Dr. Rafael Vargas, ortopedista em São Paulo.",
    "2026-06-23","23 de junho de 2026"),
}

def parse_articles(md):
    arts = []
    # blocos que começam com "## N — Título"
    blocks = re.split(r'^##\s+', md, flags=re.M)[1:]
    for b in blocks:
        lines = b.strip().split("\n")
        head = lines[0].strip()
        m = re.match(r'(\d+)\s*[—-]\s*(.+)', head)
        if not m:
            continue
        aid = int(m.group(1)); title = m.group(2).strip()
        rest = "\n".join(lines[1:])
        rest = rest.split("\n---")[0]  # corta no separador
        paras = [p.strip().replace("\n", " ") for p in re.split(r'\n\s*\n', rest) if p.strip()]
        arts.append({"id": aid, "title": title, "paras": paras})
    return arts

def lead_bold(p):
    """Negrita o rótulo inicial curto (ex.: 'Por que acontece?') p/ escaneabilidade."""
    m = re.match(r'(.{3,70}?[.?])\s+(.+)', p, flags=re.S)
    if m and len(m.group(1)) <= 70 and m.group(1).count(" ") <= 10:
        return "<strong>%s</strong> %s" % (html.escape(m.group(1)), html.escape(m.group(2)))
    return html.escape(p)

PAGE = """<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>@@TITLE@@ | Dr. Rafael Vargas</title>
<meta name="description" content="@@DESC@@">
<meta name="author" content="Dr. Rafael Vargas">
<link rel="canonical" href="@@URL@@">
<meta property="og:type" content="article">
<meta property="og:title" content="@@TITLE@@">
<meta property="og:description" content="@@DESC@@">
<meta property="og:locale" content="pt_BR">
<meta property="og:url" content="@@URL@@">
<meta name="robots" content="index, follow">
<link rel="stylesheet" href="blog.css">
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "MedicalWebPage",
  "headline": "@@TITLE_J@@",
  "description": "@@DESC_J@@",
  "datePublished": "@@DATE@@",
  "dateModified": "@@DATE@@",
  "inLanguage": "pt-BR",
  "url": "@@URL@@",
  "author": { "@type": "Physician", "name": "Dr. Rafael Vargas", "url": "@@SITE@@/" },
  "publisher": { "@type": "Person", "name": "Dr. Rafael Vargas" },
  "isPartOf": { "@type": "Blog", "name": "Blog do Dr. Rafael Vargas", "url": "@@SITE@@/blog/" }
}
</script>
</head>
<body>
<header>
  <div class="wrap nav">
    <a class="logo" href="../index.html"><span class="mark">RV</span> Dr. Rafael Vargas</a>
    <nav>
      <a href="index.html">Blog</a>
      <a href="../index.html#contato">Contato</a>
      <a class="cta" href="https://www.doctoralia.com.br/rafael-vargas" target="_blank" rel="noopener">Agendar consulta</a>
    </nav>
  </div>
</header>
<main class="wrap article">
  <a class="back" href="index.html">← Todos os artigos</a>
  <p class="meta">@@DATELABEL@@ · Ortopedia e Reconstrução Óssea</p>
  <h1>@@TITLE@@</h1>
@@BODY@@
  <div class="endcard">
    <p class="disc">@@DISC@@</p>
    <p class="sig">@@SIG@@</p>
    <div class="endbtns">
      <a class="btn btn-primary" href="https://www.doctoralia.com.br/rafael-vargas" target="_blank" rel="noopener">Agendar pela Doctoralia</a>
      <a class="btn btn-ghost" href="https://wa.me/551132801413" target="_blank" rel="noopener">WhatsApp · (11) 3280-1413</a>
    </div>
  </div>
  @@RELATED@@
</main>
<footer>
  <div class="wrap foot">
    <div>
      <span class="fsig">Dr. Rafael Vargas · Médico · CRM-SP 226103 · RQE 137901</span>
      <div class="fdisc">Conteúdo informativo e educativo. Não substitui a avaliação médica presencial nem estabelece relação médico-paciente.</div>
    </div>
    <div><a href="https://www.instagram.com/rafaelvargasmd" target="_blank" rel="noopener">@rafaelvargasmd</a></div>
  </div>
</footer>
</body>
</html>
"""

def build():
    md = open(SRC, encoding="utf-8").read()
    arts = parse_articles(md)
    for a in arts:
        slug, desc, date, dlabel = META[a["id"]]
        a.update(slug=slug, desc=desc, date=date, dlabel=dlabel,
                 url="%s/blog/%s.html" % (SITE, slug))
    by_id = {a["id"]: a for a in arts}
    order_new = sorted(arts, key=lambda a: a["id"], reverse=True)  # mais novos primeiro

    # páginas de artigo
    for a in arts:
        body = []
        for i, p in enumerate(a["paras"]):
            cls = ' class="lead"' if i == 0 else ""
            txt = html.escape(p) if i == 0 else lead_bold(p)
            body.append("  <p%s>%s</p>" % (cls, txt))
        # relacionados: 2 vizinhos
        rel = [x for x in order_new if x["id"] != a["id"]][:3]
        rel_html = ('  <aside class="related"><h2>Leia também</h2><ul>'
                    + "".join('<li><a href="%s.html">%s</a></li>' % (r["slug"], html.escape(r["title"])) for r in rel)
                    + "</ul></aside>")
        page = (PAGE
            .replace("@@TITLE_J@@", a["title"].replace('"','\\"'))
            .replace("@@DESC_J@@", a["desc"].replace('"','\\"'))
            .replace("@@TITLE@@", html.escape(a["title"]))
            .replace("@@DESC@@", html.escape(a["desc"]))
            .replace("@@URL@@", a["url"]).replace("@@SITE@@", SITE)
            .replace("@@DATE@@", a["date"]).replace("@@DATELABEL@@", a["dlabel"])
            .replace("@@BODY@@", "\n".join(body))
            .replace("@@RELATED@@", rel_html)
            .replace("@@DISC@@", html.escape(DISC)).replace("@@SIG@@", html.escape(SIG)))
        open(os.path.join(HERE, a["slug"] + ".html"), "w", encoding="utf-8").write(page)

    # índice do blog
    cards = []
    for a in order_new:
        cards.append(
          '    <a class="post" href="%s.html"><span class="pdate">%s</span>'
          '<h2>%s</h2><p>%s</p><span class="more">Ler artigo →</span></a>'
          % (a["slug"], a["dlabel"], html.escape(a["title"]), html.escape(a["desc"])))
    idx = INDEX.replace("@@CARDS@@", "\n".join(cards)).replace("@@SITE@@", SITE)
    open(os.path.join(HERE, "index.html"), "w", encoding="utf-8").write(idx)

    # trecho p/ a home (3 mais novos)
    home_cards = []
    for a in order_new[:3]:
        home_cards.append(
          '        <a class="post" href="blog/%s.html"><span class="pdate">%s</span>'
          '<h3>%s</h3><p>%s</p><span class="more">Ler artigo →</span></a>'
          % (a["slug"], a["dlabel"], html.escape(a["title"]), html.escape(a["desc"])))
    open(os.path.join(HERE, "_home_blog_section.html"), "w", encoding="utf-8").write("\n".join(home_cards))

    open(os.path.join(HERE, "blog.css"), "w", encoding="utf-8").write(CSS)
    print("OK: %d artigos + index.html + blog.css gerados." % len(arts))

INDEX = """<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Blog | Dr. Rafael Vargas — Ortopedia e Reconstrução Óssea, São Paulo</title>
<meta name="description" content="Artigos educativos sobre ortopedia pediátrica, reconstrução e alongamento ósseo, deformidades e fraturas de difícil solução. Por Dr. Rafael Vargas, São Paulo.">
<link rel="canonical" href="@@SITE@@/blog/">
<meta property="og:type" content="website">
<meta property="og:title" content="Blog do Dr. Rafael Vargas">
<meta property="og:locale" content="pt_BR">
<meta name="robots" content="index, follow">
<link rel="stylesheet" href="blog.css">
</head>
<body>
<header>
  <div class="wrap nav">
    <a class="logo" href="../index.html"><span class="mark">RV</span> Dr. Rafael Vargas</a>
    <nav>
      <a href="../index.html#sobre">Sobre</a>
      <a href="../index.html#contato">Contato</a>
      <a class="cta" href="https://www.doctoralia.com.br/rafael-vargas" target="_blank" rel="noopener">Agendar consulta</a>
    </nav>
  </div>
</header>
<main class="wrap bloglist">
  <div class="bloghead">
    <div class="kicker">Blog</div>
    <h1>Conteúdo educativo sobre ortopedia e reconstrução óssea</h1>
    <p>Textos para pacientes e famílias — em linguagem clara, sem promessas, com foco em quando avaliar e o que esperar.</p>
  </div>
  <div class="posts">
@@CARDS@@
  </div>
</main>
<footer>
  <div class="wrap foot">
    <div>
      <span class="fsig">Dr. Rafael Vargas · Médico · CRM-SP 226103 · RQE 137901</span>
      <div class="fdisc">Conteúdo informativo e educativo. Não substitui a avaliação médica presencial nem estabelece relação médico-paciente.</div>
    </div>
    <div><a href="https://www.instagram.com/rafaelvargasmd" target="_blank" rel="noopener">@rafaelvargasmd</a></div>
  </div>
</footer>
</body>
</html>
"""

CSS = """:root{
  --preto:#14141A;--creme:#F3E2C8;--dourado:#B08C4F;--dourado-esc:#8F6F39;
  --fundo:#F6F4EF;--fundo-2:#FBF9F5;--tinta:#2A2823;--suave:#6E665A;
  --linha:#E6DECF;--raio:14px;--max:1080px;
}
*{box-sizing:border-box;margin:0;padding:0}
html{scroll-behavior:smooth}
body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;
  color:var(--tinta);background:var(--fundo);line-height:1.7;-webkit-font-smoothing:antialiased}
h1,h2,h3{font-family:Georgia,"Times New Roman",serif;line-height:1.2;font-weight:700;letter-spacing:-0.01em;color:var(--preto)}
a{color:var(--dourado-esc);text-decoration:none}
.wrap{max-width:var(--max);margin:0 auto;padding:0 24px}
header{position:sticky;top:0;z-index:50;background:rgba(246,244,239,.92);
  backdrop-filter:saturate(180%) blur(10px);border-bottom:1px solid var(--linha)}
.nav{display:flex;align-items:center;justify-content:space-between;height:70px}
.logo{display:flex;align-items:center;gap:12px;font-family:Georgia,serif;font-weight:700;font-size:20px;color:var(--preto)}
.logo .mark{width:38px;height:38px;border-radius:8px;background:var(--preto);
  display:grid;place-items:center;color:var(--creme);font-family:Georgia,serif;font-weight:700;font-size:16px;border:1px solid var(--dourado)}
.nav nav a{color:var(--suave);margin-left:26px;font-size:15px;font-weight:500}
.nav nav a:hover{color:var(--dourado-esc)}
.nav .cta{display:inline-block;margin-left:26px;background:var(--preto);color:var(--creme);
  padding:10px 18px;border-radius:10px;font-weight:600;font-size:14px;border:1px solid var(--dourado)}
@media(max-width:760px){.nav nav a:not(.cta){display:none}.nav .cta{margin-left:0}}
/* artigo */
.article{padding:54px 24px 30px;max-width:760px}
.article .back{display:inline-block;font-size:14px;font-weight:600;margin-bottom:22px}
.article .meta{font-size:13px;text-transform:uppercase;letter-spacing:.08em;color:var(--dourado-esc);font-weight:700;margin-bottom:12px}
.article h1{font-size:34px;margin-bottom:26px}
.article h2{font-size:23px;margin:34px 0 12px}
.article p{font-size:17.5px;margin-bottom:18px;color:var(--tinta)}
.article p.lead{font-size:20px;color:var(--preto)}
.article p strong{color:var(--preto)}
@media(max-width:760px){.article h1{font-size:27px}}
.endcard{margin-top:40px;padding:26px;background:var(--fundo-2);border:1px solid var(--linha);border-radius:var(--raio)}
.endcard .disc{font-size:13.5px;color:var(--suave);margin-bottom:14px}
.endcard .sig{font-weight:600;color:var(--preto);font-size:15px;margin-bottom:18px}
.endbtns{display:flex;gap:12px;flex-wrap:wrap}
.btn{display:inline-block;padding:13px 22px;border-radius:11px;font-weight:600;font-size:15px}
.btn-primary{background:var(--preto);color:var(--creme);border:1px solid var(--dourado)}
.btn-ghost{border:1px solid var(--linha);color:var(--preto)}
.related{margin-top:40px;border-top:1px solid var(--linha);padding-top:24px}
.related h2{font-size:18px;margin-bottom:12px}
.related ul{list-style:none}
.related li{margin-bottom:9px;padding-left:18px;position:relative}
.related li::before{content:"";position:absolute;left:0;top:11px;width:7px;height:7px;border-radius:50%;background:var(--dourado)}
.related a{color:var(--dourado-esc);font-weight:500}
/* índice */
.bloglist{padding:54px 24px 30px}
.bloghead{max-width:680px;margin-bottom:40px}
.bloghead .kicker{color:var(--dourado-esc);font-weight:700;font-size:13px;text-transform:uppercase;letter-spacing:.12em;margin-bottom:14px}
.bloghead h1{font-size:33px;margin-bottom:14px}
.bloghead p{color:var(--suave);font-size:17px}
.posts{display:grid;grid-template-columns:repeat(2,1fr);gap:22px}
@media(max-width:760px){.posts{grid-template-columns:1fr}}
.post{display:block;background:var(--fundo-2);border:1px solid var(--linha);border-radius:var(--raio);padding:26px;transition:border-color .15s,transform .15s}
.post:hover{border-color:var(--dourado);transform:translateY(-2px)}
.post .pdate{font-size:12px;text-transform:uppercase;letter-spacing:.07em;color:var(--suave);font-weight:700}
.post h2,.post h3{font-size:20px;margin:10px 0 10px}
.post p{color:var(--suave);font-size:15px;margin-bottom:14px}
.post .more{font-weight:600;color:var(--dourado-esc);font-size:14px}
/* footer */
footer{border-top:1px solid var(--linha);padding:36px 0;color:var(--suave);font-size:14px;background:var(--fundo-2);margin-top:40px}
.foot{display:flex;justify-content:space-between;gap:18px;flex-wrap:wrap}
.foot a{color:var(--suave)}
.fsig{font-weight:600;color:var(--preto)}
.fdisc{font-size:13px;color:var(--suave);margin-top:8px;max-width:640px}
"""

if __name__ == "__main__":
    build()
