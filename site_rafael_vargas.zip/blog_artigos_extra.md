# Blog — lote extra (publicado na Livance em 22/06/2026, ids 43832, 43833, 43834)
> CFM-safe: educativo, sem promessa de resultado, paciente não identificável, assinatura nome+CRM+RQE + disclaimer. Guardrail respeitado: alongamento ósseo só em contexto funcional (discrepância/reconstrução), nunca estético/altura. Complementa `blog_artigos.md` (1-3) e `blog_artigos_pediatria.md` (4-5).

---

## Artigo 6 — Joelho varo e valgo na criança (pernas arqueadas ou em "xis"): quando avaliar

É comum os pais notarem que a criança tem as pernas "arqueadas" (joelho varo) ou em formato de "xis" (joelho valgo) e ficarem na dúvida se é normal. Na maioria das vezes, faz parte do desenvolvimento — mas alguns casos merecem avaliação.

O que é normal no desenvolvimento. O alinhamento das pernas muda com a idade: bebês costumam ter as pernas mais arqueadas (varo), que tendem a se corrigir nos primeiros anos; mais tarde, por volta dos 3 a 4 anos, é comum um período de joelho valgo ("xis"), que também costuma se ajustar com o crescimento. Ou seja, ver uma curvatura em certa idade nem sempre é problema.

Quando merece avaliação. Vale procurar um especialista quando a curvatura é acentuada ou aparece só de um lado (assimétrica); quando piora em vez de melhorar com a idade; quando vem acompanhada de baixa estatura desproporcional, dor ou claudicação; ou quando há uma doença de base conhecida (como raquitismo ou displasias). Esses sinais ajudam a diferenciar o que é desenvolvimento do que precisa de acompanhamento.

Como é a avaliação. Inclui exame clínico, observação da marcha, medidas do alinhamento e, quando indicado, exames de imagem. O objetivo é entender se a curvatura tende a se corrigir sozinha ou se há algo que se beneficia de acompanhamento ou tratamento — sempre explicando aos pais o que esperar.

A mensagem para os pais. Curvatura nas pernas da criança costuma ser parte do crescimento. Mas assimetria, piora ou dor merecem uma avaliação, que tranquiliza quando está tudo certo e permite agir na hora certa quando é necessário.

*Este conteúdo é informativo e educativo, não substitui a consulta médica presencial nem estabelece relação médico-paciente. Cada caso exige avaliação individual; não há garantia de resultado.*

**Dr. Rafael Vargas — Médico · CRM-SP 226103 · RQE 137901** — Ortopedia Pediátrica · Reconstrução e Alongamento Ósseo — São Paulo

---

## Artigo 7 — Consolidação viciosa: quando a fratura cola fora do lugar

Nem toda fratura que "cola" consolida na posição ideal. Quando o osso une, mas com desvio de alinhamento, rotação ou encurtamento, chamamos de consolidação viciosa. Diferente da pseudartrose (em que o osso não chega a unir), aqui o osso consolidou — só que fora da posição correta.

Por que acontece. Pode resultar de uma fratura que consolidou sem alinhamento adequado, de desvios que surgem durante a consolidação, ou de fraturas complexas em que manter a posição é difícil. Em crianças, o crescimento às vezes corrige parte do desvio — em outras, pode acentuá-lo, por isso o acompanhamento importa.

Quais as consequências. Dependendo do grau e da localização, a consolidação viciosa pode causar desalinhamento visível do membro, diferença de comprimento, alteração da marcha, sobrecarga das articulações vizinhas e desconforto. Casos leves podem não dar sintomas; outros se beneficiam de correção.

Como se avalia o tratamento. A avaliação mede o desvio (angular, rotacional e de comprimento) com exame clínico e de imagem, e considera o impacto funcional. Quando indicada, a correção pode envolver técnicas de reconstrução — incluindo osteotomias (cortes ósseos planejados) e, em casos selecionados, correção gradual com fixadores. Cada caso é individualizado e discutido com o paciente.

Quando procurar avaliação. Se você percebe um membro "torto" depois de uma fratura, diferença de comprimento ou dificuldade para usá-lo, vale uma avaliação para entender o desvio e os caminhos possíveis.

*Este conteúdo é informativo e educativo, não substitui a consulta médica presencial nem estabelece relação médico-paciente. Cada caso exige avaliação individual; não há garantia de resultado.*

**Dr. Rafael Vargas — Médico · CRM-SP 226103 · RQE 137901** — Ortopedia Pediátrica · Reconstrução e Alongamento Ósseo — São Paulo

---

## Artigo 8 — Sequelas de fraturas e de infecções ósseas: quando a reconstrução entra

Algumas fraturas e infecções ósseas deixam sequelas que vão além do episódio inicial: perda de osso, desalinhamento, encurtamento, rigidez ou áreas que não cicatrizam bem. Esses quadros — muitas vezes de difícil solução — são parte central da ortopedia reconstrutiva.

Que tipo de sequela. Entre as mais comuns estão: pseudartrose (fratura que não consolida), consolidação viciosa (osso unido fora de posição), discrepância de comprimento, perda óssea segmentar (falta de um trecho do osso) e sequelas de osteomielite (infecção do osso). Com frequência, mais de um desses problemas coexistem.

Por que exigem planejamento. Tratar uma sequela não é repetir a cirurgia inicial — é entender o que ficou para trás (osso, partes moles, presença ou não de infecção) e construir um plano em etapas. O controle de uma eventual infecção costuma ser pré-requisito antes de reconstruir.

Como a reconstrução ajuda. O arsenal inclui técnicas de reconstrução e alongamento ósseo, transporte ósseo para preencher perdas, correção de eixo e de comprimento, e o uso de fixadores com correção gradual quando indicado — sempre individualizado, priorizando função, alinhamento e qualidade de vida.

Quando procurar avaliação. Se você convive com as consequências de uma fratura ou infecção óssea antiga — dor, desalinhamento, encurtamento ou feridas que não fecham — vale uma avaliação especializada para entender a causa e os caminhos possíveis.

*Este conteúdo é informativo e educativo, não substitui a consulta médica presencial nem estabelece relação médico-paciente. Cada caso exige avaliação individual; não há garantia de resultado.*

**Dr. Rafael Vargas — Médico · CRM-SP 226103 · RQE 137901** — Ortopedia Pediátrica · Reconstrução e Alongamento Ósseo — São Paulo
