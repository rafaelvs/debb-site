# Blog — lote pediátrico 2 (alto volume de busca) — publicado na Livance em 22/06/2026
> CFM-safe: educativo, sem promessa de resultado, paciente não identificável, assinatura nome+CRM+RQE + disclaimer. Complementa blog_artigos.md (1-3), blog_artigos_pediatria.md (4-5), blog_artigos_extra.md (6-8).

---

## Artigo 9 — Displasia do desenvolvimento do quadril (DDQ): por que avaliar cedo faz diferença

A displasia do desenvolvimento do quadril (DDQ) é uma condição em que a articulação do quadril não se forma ou não se mantém na posição adequada. Ela vai desde um quadril mais "frouxo" até situações em que a cabeça do fêmur fica fora do lugar (luxação). Quanto mais cedo é identificada, mais simples costuma ser o acompanhamento.

Por que acontece e quem tem mais risco. A DDQ tem relação com fatores como histórico familiar, posição pélvica na gestação (bebê sentado, "de nádegas"), ser o primeiro filho e o sexo feminino. Nem toda criança com fator de risco terá o problema — mas esses dados ajudam a decidir quem merece uma avaliação mais atenta.

Como é identificada. Nos primeiros meses, o exame clínico (manobras específicas no quadril do bebê) e, quando indicado, a ultrassonografia ajudam no diagnóstico; em crianças maiores, a radiografia passa a ser útil. Sinais como assimetria das pregas da coxa, diferença na abertura das pernas ou, mais tarde, um jeito diferente de andar podem chamar atenção.

Por que o tempo importa. Quando identificada cedo, a DDQ costuma ser conduzida com medidas mais simples e conservadoras. Diagnósticos mais tardios podem exigir condutas mais complexas. Por isso o acompanhamento nos primeiros meses e a triagem nas consultas de rotina são tão valorizados.

Quando procurar avaliação. Se há fatores de risco, assimetria nas pernas do bebê, dificuldade para abrir o quadril ou alteração na marcha quando a criança começa a andar, vale uma avaliação especializada — que tranquiliza quando está tudo bem e permite agir na hora certa quando necessário.

*Este conteúdo é informativo e educativo, não substitui a consulta médica presencial nem estabelece relação médico-paciente. Cada caso exige avaliação individual; não há garantia de resultado.*

**Dr. Rafael Vargas — Médico · CRM-SP 226103 · RQE 137901** — Ortopedia Pediátrica · Reconstrução e Alongamento Ósseo — São Paulo

---

## Artigo 10 — Pé torto congênito: o que é e como é o acompanhamento

O pé torto congênito (pé equinovaro) é uma deformidade presente desde o nascimento em que o pé aparece virado para baixo e para dentro. É relativamente comum e, com acompanhamento adequado iniciado cedo, costuma ter boa evolução funcional.

O que se sabe sobre a causa. Na maioria dos casos é idiopático (sem uma causa única identificável), podendo haver componente genético; em parte dos casos está associado a outras condições. O importante para a família é entender que não se trata de "algo que os pais fizeram" — e que existe um caminho de tratamento bem estabelecido.

Como costuma ser conduzido. O acompanhamento moderno geralmente começa nas primeiras semanas de vida, com correção gradual por trocas de gesso (método de Ponseti) e, frequentemente, um procedimento simples no tendão de Aquiles, seguido do uso de órteses por um período para evitar recidiva. Cada caso é individualizado.

Por que a adesão importa. Boa parte do bom resultado depende de iniciar cedo e seguir todas as etapas, especialmente o uso das órteses na fase de manutenção. Interrupções aumentam a chance de o pé "voltar" para a posição antiga, o que pode demandar novas correções.

Quando procurar avaliação. Se o bebê nasceu com um ou ambos os pés virados, ou se há dúvida sobre o formato e a posição do pé, vale procurar avaliação especializada o quanto antes — o início precoce costuma simplificar todo o percurso.

*Este conteúdo é informativo e educativo, não substitui a consulta médica presencial nem estabelece relação médico-paciente. Cada caso exige avaliação individual; não há garantia de resultado.*

**Dr. Rafael Vargas — Médico · CRM-SP 226103 · RQE 137901** — Ortopedia Pediátrica · Reconstrução e Alongamento Ósseo — São Paulo

---

## Artigo 11 — Como é a primeira consulta com o ortopedista: o que levar e o que esperar

A primeira consulta é o ponto de partida para entender o seu caso (ou o do seu filho) e construir um plano. Saber o que esperar ajuda a aproveitar melhor esse tempo.

O que levar. Vale reunir os exames de imagem já realizados (radiografias, tomografias, ressonâncias) — de preferência as imagens, não só os laudos —, relatórios de cirurgias ou tratamentos anteriores, a lista de medicamentos em uso e um breve histórico do problema (quando começou, como evoluiu, o que já foi tentado). No caso de crianças, informações sobre a gestação, o parto e o desenvolvimento podem ser úteis.

Como costuma ser. A consulta inclui conversa sobre a queixa e o histórico, exame físico (avaliação do alinhamento, da marcha e da mobilidade) e revisão dos exames trazidos. A partir disso, discutimos as hipóteses diagnósticas, a necessidade ou não de exames complementares e os caminhos possíveis — sempre explicando o porquê de cada conduta.

Sobre expectativas. Nem todo caso se resolve em uma única consulta: muitos quadros complexos exigem investigação por etapas e planejamento. O objetivo do primeiro encontro é entender o problema com clareza e alinhar os próximos passos, não necessariamente decidir tudo de imediato.

Perguntas são bem-vindas. Anote suas dúvidas antes da consulta — sobre diagnóstico, alternativas, riscos e tempo de recuperação. Uma boa decisão é aquela construída em conjunto, com informação clara.

*Este conteúdo é informativo e educativo, não substitui a consulta médica presencial nem estabelece relação médico-paciente. Cada caso exige avaliação individual; não há garantia de resultado.*

**Dr. Rafael Vargas — Médico · CRM-SP 226103 · RQE 137901** — Ortopedia Pediátrica · Reconstrução e Alongamento Ósseo — São Paulo
