# Artigos para o Blog da Livance — Dr. Rafael Vargas
> Conteúdo educativo, em conformidade com a Resolução CFM 2.336/2023: sem promessa/garantia de resultado, sem sensacionalismo, sem paciente identificável, tom sóbrio. Cada artigo traz assinatura (nome + CRM + RQE) e disclaimer. Palavras-chave de busca local inseridas naturalmente (condição + São Paulo).

---

## Artigo 1 — Discrepância de comprimento dos membros ("perna mais curta"): o que é e quando avaliar

Você já reparou que uma perna parece mais curta que a outra, que há uma claudicação ao andar ou que um dos sapatos desgasta diferente? A diferença de comprimento entre os membros — chamada de **discrepância de comprimento dos membros** — é uma condição relativamente comum, que pode surgir no nascimento ou ao longo da vida.

**Por que acontece?** As causas são variadas: diferenças congênitas, sequelas de fraturas que consolidaram em posição inadequada, infecções ósseas, alterações do crescimento na infância ou doenças de base que afetam o desenvolvimento do osso. Em crianças, a diferença pode aumentar à medida que crescem, por isso o acompanhamento ao longo do crescimento é importante.

**Por que avaliar?** Diferenças pequenas muitas vezes não causam sintomas. Já diferenças maiores podem se associar a claudicação, sobrecarga da coluna e das articulações e desconforto ao caminhar. A avaliação busca entender a magnitude da diferença, sua causa e como ela tende a evoluir — especialmente na criança em crescimento, em que existe uma "janela" de tratamento que muda conforme a idade.

**Como é a avaliação?** Combina exame clínico, medidas e exames de imagem para medir a diferença com precisão e investigar a origem. A partir desse entendimento, discute-se, de forma individualizada, o que faz sentido para cada caso — desde acompanhamento até abordagens de correção, sempre explicando as alternativas e o que esperar de cada etapa.

**Quando procurar um especialista?** Vale uma avaliação quando há diferença perceptível no comprimento das pernas, claudicação, ou quando uma criança apresenta assimetria que parece aumentar com o tempo. O encaminhamento precoce ajuda a planejar com calma, no momento mais adequado.

*Este conteúdo é informativo e educativo, não substitui a consulta médica presencial nem estabelece relação médico-paciente. Cada caso exige avaliação individual; não há garantia de resultado.*

**Dr. Rafael Vargas — Médico · CRM-SP 226103 · RQE 137901**
Ortopedia Pediátrica · Reconstrução e Alongamento Ósseo — São Paulo

---

## Artigo 2 — Pseudartrose: quando a fratura não consolida

A maioria das fraturas consolida (cola) dentro de um período esperado. Quando esse processo não acontece e o osso permanece sem unir além do tempo previsto, falamos em **pseudartrose** — literalmente, uma "falsa articulação", em que persiste mobilidade no ponto que deveria estar consolidado.

**Por que algumas fraturas não consolidam?** A consolidação depende de fatores como estabilidade no foco da fratura, vascularização (irrigação sanguínea) e ausência de infecção. Fraturas expostas, perdas ósseas, infecções, certas localizações e fatores individuais podem dificultar a união. Identificar **por que** aquela fratura não consolidou é parte central da avaliação, porque orienta a conduta.

**Quais sinais chamam atenção?** Dor persistente no local, sensação de instabilidade ou movimento anormal, e dificuldade de uso do membro tempos depois de uma fratura que "deveria" ter colado. O diagnóstico é confirmado com exame clínico e de imagem.

**Como se avalia o tratamento?** O planejamento é individualizado e costuma considerar a estabilidade do foco, a qualidade do osso e dos tecidos ao redor, e a presença ou não de infecção. Técnicas de reconstrução óssea — incluindo, em casos selecionados, o uso de fixadores e a correção gradual — fazem parte do arsenal da ortopedia reconstrutiva para esse tipo de problema. Cada alternativa, com seus riscos e suas etapas, é discutida com o paciente.

**Por que procurar avaliação especializada?** A pseudartrose costuma ser um problema de difícil solução, que se beneficia de planejamento minucioso e visão de longo prazo. Se você convive com dor e instabilidade muito tempo após uma fratura, vale uma avaliação para entender a causa e os caminhos possíveis.

*Este conteúdo é informativo e educativo, não substitui a consulta médica presencial nem estabelece relação médico-paciente. Cada caso exige avaliação individual; não há garantia de resultado.*

**Dr. Rafael Vargas — Médico · CRM-SP 226103 · RQE 137901**
Ortopedia Pediátrica · Reconstrução e Alongamento Ósseo — São Paulo

---

## Artigo 3 — Fixador externo e correção gradual: entendendo o tratamento das deformidades

Quando se fala em **fixador externo**, é comum surgir certo receio — em parte por desconhecimento de como o tratamento funciona no dia a dia. Este texto busca explicar, de forma educativa, o papel dessa ferramenta na correção de deformidades e na reconstrução óssea.

**O que é?** O fixador externo é um dispositivo que estabiliza o osso a partir de fora do corpo, por meio de pinos ou fios. Ele permite, em situações selecionadas, fazer correções de forma **gradual** — ajustando alinhamento e comprimento ao longo do tempo, respeitando a biologia do osso e dos tecidos.

**Em que situações pode ser indicado?** Correção de deformidades dos membros (desvios de eixo), tratamento de discrepância de comprimento, reconstrução em casos de perda óssea, sequelas de fraturas e de infecções, e algumas pseudartroses. A indicação é sempre individualizada: nem todo caso precisa de fixador, e a decisão considera o objetivo funcional de cada pessoa.

**Como é conviver com o fixador?** O tratamento é conduzido em etapas, com acompanhamento ao longo do período. Os cuidados com os pinos, a rotina e o tempo de uso são explicados com clareza desde o início, para que o paciente e a família saibam o que esperar de cada fase. A correção gradual exige paciência, e o acompanhamento próximo faz parte do processo.

**A mensagem principal:** o fixador é um meio para um fim — restaurar função, alinhamento e qualidade de vida em quadros complexos. Mais importante que a ferramenta é o planejamento por trás dela: entender a causa da deformidade e construir, junto com o paciente, um plano realista e individualizado.

*Este conteúdo é informativo e educativo, não substitui a consulta médica presencial nem estabelece relação médico-paciente. Cada caso exige avaliação individual; não há garantia de resultado.*

**Dr. Rafael Vargas — Médico · CRM-SP 226103 · RQE 137901**
Ortopedia Pediátrica · Reconstrução e Alongamento Ósseo — São Paulo
